package com.satori.rtm;

public enum PersistenceHistoryMode {
  POSITIONS,
  TIMESTAMPS
}
