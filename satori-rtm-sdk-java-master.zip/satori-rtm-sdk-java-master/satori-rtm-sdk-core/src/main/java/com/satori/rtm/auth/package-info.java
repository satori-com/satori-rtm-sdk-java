/**
 * Classes that manage authentication.
 */
package com.satori.rtm.auth;
