/**
 * Classes related to the RTM connection for sending and receiving PDUs and JSON serializer.
 */
package com.satori.rtm.connection;
