/**
 * RTM client and connection classes. Use
 * {@link com.satori.rtm.RtmClientBuilder} to create an RTM client.
 */
package com.satori.rtm;
