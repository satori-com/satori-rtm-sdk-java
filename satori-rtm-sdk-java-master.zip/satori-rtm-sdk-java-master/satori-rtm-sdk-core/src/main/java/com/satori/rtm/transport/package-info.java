/**
 * Classes related to WebSocket transport implementation.
 */
package com.satori.rtm.transport;
