/**
 * Utility classes for the RTM SDK.
 */
package com.satori.rtm.utils;
