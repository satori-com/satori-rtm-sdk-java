/**
 * Typical examples of SDK usage
 */
package examples;
